/*
 * gestion_can.c
 *
 *  Created on: May 17, 2022
 *      Author: GatienJost
 */
#include "gestion_can.h"

CanHandler_t canHandler;

void CAN_Init(CanHandler_t *handler, CAN_HandleTypeDef *can)
{
	handler->halStruct = can;

	HAL_CAN_Start(handler->halStruct);

	// Activate the notification
	HAL_CAN_ActivateNotification(handler->halStruct, CAN_IT_RX_FIFO1_MSG_PENDING);

	/*
	//Filter Config
	handler->canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
	handler->canfilterconfig.FilterBank = 18;  // which filter bank to use from the assigned ones
	handler->canfilterconfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	handler->canfilterconfig.FilterIdHigh = 0x446<<5;
	handler->canfilterconfig.FilterIdLow = 0;
	handler->canfilterconfig.FilterMaskIdHigh = 0x446<<5;
	handler->canfilterconfig.FilterMaskIdLow = 0x0000;
	handler->canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
	handler->canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
	handler->canfilterconfig.SlaveStartFilterBank = 20;  // how many filters to assign to the CAN1 (master can)
	HAL_CAN_ConfigFilter(handler->halStruct, &handler->canfilterconfig);
	*/
}

void CAN_Send(CanHandler_t *handler, uint8_t *pData, uint32_t size)
{
	if(size>8){
		size = 8;
	}

	handler->TxHeader.IDE = CAN_ID_STD;
	handler->TxHeader.StdId = 0x1;
	handler->TxHeader.RTR = CAN_RTR_DATA;
	handler->TxHeader.DLC = size;

	for(int i=0 ; i<size ; i++)
	{
		handler->TxData[i] = pData[i];
	}

	HAL_CAN_AddTxMessage(handler->halStruct, &handler->TxHeader, handler->TxData, &handler->TxMailbox);
}
