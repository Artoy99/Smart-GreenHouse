/*
 * gestion_can.c
 *
 *  Created on: May 17, 2022
 *      Author: GatienJost
 */
#include "main.h"
#include "gestion_can.h"
#include "can_messages.h"

#include <stdio.h>
#include <string.h>

CanHandler_t canHandler;

void CAN_Task(void){
	if(canHandler.datacheck){
		canHandler.datacheck = RESET;

		if(canHandler.RxData[0] == ID_STM32_3){
			HumWrite(canHandler.RxData[7]);
		}
	}
}

void CAN_Init(CAN_HandleTypeDef *hcan)
{
	canHandler.halStruct = hcan;
	canHandler.datacheck = RESET;

	CAN_ConfigFilters();

	HAL_CAN_Start(canHandler.halStruct);

	// Activate the notification
	if( HAL_CAN_ActivateNotification(canHandler.halStruct, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
	{
		Error_Handler();
	}
}

void CAN_ConfigFilters(void){
	CAN_FilterTypeDef sFilterConfig;
	sFilterConfig.FilterBank = 0;
	sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
	sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
	sFilterConfig.FilterIdHigh = 0x0000;
	sFilterConfig.FilterIdLow = 0x0000;
	sFilterConfig.FilterMaskIdHigh = 0x0000;
	sFilterConfig.FilterMaskIdLow = 0x0000;
	sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
	sFilterConfig.FilterActivation = ENABLE;
	sFilterConfig.SlaveStartFilterBank = 14;
	HAL_CAN_ConfigFilter(canHandler.halStruct, &sFilterConfig);
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
	if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &canHandler.RxHeader, canHandler.RxData) == HAL_OK)
	{
		canHandler.datacheck = SET;
	}
}

void CAN_Send(uint8_t *pData, uint8_t size)
{
	if(size>8){
		size = 8;
	}

	canHandler.TxHeader.IDE = CAN_ID_STD;
	canHandler.TxHeader.StdId = 0x12;
	canHandler.TxHeader.RTR = CAN_RTR_DATA;
	canHandler.TxHeader.DLC = size;

//	canHandler.TxHeader.IDE = CAN_ID_STD;
//	canHandler.TxHeader.StdId = 0x2;
//	canHandler.TxHeader.RTR = CAN_RTR_DATA;
//	canHandler.TxHeader.DLC = size;

	HAL_CAN_AddTxMessage(canHandler.halStruct, &canHandler.TxHeader, pData, &canHandler.TxMailbox);
}

