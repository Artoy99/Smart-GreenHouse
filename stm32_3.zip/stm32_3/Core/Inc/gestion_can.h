/*
 * gestion_can.h
 *
 *  Created on: May 17, 2022
 *      Author: GatienJost
 */

#ifndef INC_GESTION_CAN_H_
#define INC_GESTION_CAN_H_

#include "stm32f3xx.h"

typedef struct{
	CAN_HandleTypeDef     *halStruct;
	CAN_TxHeaderTypeDef   TxHeader;
	CAN_FilterTypeDef 	  canfilterconfig;
	uint8_t               TxData[8];
	uint32_t              TxMailbox;
}CanHandler_t;

void CAN_Init(CanHandler_t *handler, CAN_HandleTypeDef *can);

void CAN_Send(CanHandler_t *handler, uint8_t *pData, uint32_t size);

extern CanHandler_t canHandler;

#endif /* INC_GESTION_CAN_H_ */
