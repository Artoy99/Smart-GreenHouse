/*
 * gestion_can.h
 *
 *  Created on: May 17, 2022
 *      Author: GatienJost
 */

#ifndef INC_GESTION_CAN_H_
#define INC_GESTION_CAN_H_

#include "stm32f3xx.h"

typedef struct{
	uint8_t boardId;
	CAN_HandleTypeDef     *halStruct;
	CAN_TxHeaderTypeDef   TxHeader;
	CAN_RxHeaderTypeDef   RxHeader;
	CAN_FilterTypeDef 	  canfilterconfig;
	uint8_t               TxData[8];
	uint8_t               RxData[8];
	uint32_t              TxMailbox;
	uint8_t				  datacheck;
}CanHandler_t;

void CAN_Task(void);
void CAN_Init(CAN_HandleTypeDef *hcan);
void CAN_ConfigFilters(void);
void CAN_Send(uint8_t *pData, uint8_t size);

void HAL_CAN_RxFifo0MsgPendingCallback();

uint8_t CAN_GetDatacheck();
void CAN_SetDatacheck(uint8_t value);

extern CanHandler_t canHandler;

#endif /* INC_GESTION_CAN_H_ */
