#include "mbed.h"
#include "CANMsg.h"
#include <cstdint>

// Read temperature from LM75BD

I2C i2c(I2C_SDA, I2C_SCL);
CAN can(PA_11, PA_12);

const int addr8bit = 0x28 << 1; 

int main()
{
    can.frequency(125000);
    CANMsg msg;
    while (1) {
        char cmd[2] = {0x05, 0x06};
        i2c.write(addr8bit, cmd, 2);
        i2c.read(addr8bit, cmd, 2);

        uint16_t result = cmd[0] << 8 | cmd[1];
        
        msg.clear();
        msg.id = 0x13;
        msg << cmd[0];
        msg << cmd[1];
        can.write(msg);
    }
}